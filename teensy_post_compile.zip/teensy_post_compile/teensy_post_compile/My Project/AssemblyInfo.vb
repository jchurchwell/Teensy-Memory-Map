﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("teensy_post_compile")>
<Assembly: AssemblyDescription("Used to output the list of variables, their base memory location, and size in bytes")>
<Assembly: AssemblyCompany("Joe Churchwell")>
<Assembly: AssemblyProduct("teensy_post_compile")>
<Assembly: AssemblyCopyright("Copyright ©  201")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("22cf65ea-ac2c-4a6c-a999-24c96adc103c")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.1")>
<Assembly: AssemblyFileVersion("1.0.0.1")>
